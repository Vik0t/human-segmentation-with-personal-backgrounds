import json
from PIL import Image, ImageDraw, ImageFont, ImageColor
import requests
from io import BytesIO
import qrcode
from qrcode.image.styledpil import StyledPilImage
from qrcode.image.styles.moduledrawers import RoundedModuleDrawer

# --- Конфигурация ---
FONT_PATH_SANSATION = "/home/dusty/hackotons/human-segmentation-with-personal-backgrounds/Background_gen/Sansation-Bold.ttf"
BACKGROUND_IMAGE_PATH = "/home/dusty/Downloads/7ixg1BJM_Кейс Цифровой дресс-код_2025_10_23_0905_50.701080_+0000/Подложки DION/1920х1080.png"

def recolor_icon(icon_path, color):
    icon = Image.open(icon_path).convert("RGBA")
    data = icon.getdata()
    new_data = []
    for item in data:
        if item[3] > 0:
            new_data.append((color[0], color[1], color[2], item[3]))
        else:
            new_data.append(item)
    icon.putdata(new_data)
    return icon

def get_background_brightness(image_path, sample_size=512):
    img = Image.open(image_path).convert("RGB")
    img = img.resize((sample_size, sample_size), Image.LANCZOS)
    pixels = list(img.getdata())
    brightness = sum(sum(p) for p in pixels) / (len(pixels) * 3)
    return brightness

def load_font(size):
    try:
        return ImageFont.truetype(FONT_PATH_SANSATION, int(size))
    except OSError:
        return ImageFont.load_default()

def load_image_from_url(url):
    headers = {
        'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.1.0 YaBrowser/22.2.1.0 Safari/537.36'
    }
    try:
        response = requests.get(url, headers=headers)
        response.raise_for_status()
        return Image.open(BytesIO(response.content))
    except Exception as e:
        print(f"Ошибка загрузки изображения {url}: {e}")
        return None

def qr_round(url: str, primary=(0, 82, 204), secondary=(0, 184, 217), use_gradient=True):
    qr = qrcode.QRCode(
        error_correction=qrcode.constants.ERROR_CORRECT_H,
        version=3,
        border=1,
        box_size=15
    )
    qr.add_data(url)
    qr.make(fit=True)

    if not use_gradient:
        return qr.make_image(fill_color="black", back_color="white").convert("RGBA")

    base_img = qr.make_image(fill_color="black", back_color="white")
    width, height = base_img.size
    gradient_img = Image.new("RGBA", (width, height))

    for y in range(height):
        ratio = y / height
        r = int(primary[0] + (secondary[0] - primary[0]) * ratio)
        g = int(primary[1] + (secondary[1] - primary[1]) * ratio)
        b = int(primary[2] + (secondary[2] - primary[2]) * ratio)
        for x in range(width):
            gradient_img.putpixel((x, y), (r, g, b, 255))

    mask = base_img.convert("L").point(lambda x: 255 if x == 0 else 0)
    result = Image.new("RGBA", (width, height))
    result.paste(gradient_img, (0, 0), mask)
    return result

def darken_color(color, factor=0.6):
    return tuple(int(c * factor) for c in color)

def draw_text_in_box(draw, text, x, y, max_width, max_height, fill_color):
    size = 48
    best_font = None
    best_bbox = None

    while size >= 10:
        font = load_font(size)
        bbox = draw.textbbox((0, 0), text, font=font)
        w = bbox[2] - bbox[0]
        h = bbox[3] - bbox[1]
        if w <= max_width and h <= max_height:
            best_font = font
            best_bbox = bbox
            break
        size -= 1

    if best_font is None:
        best_font = load_font(10)
        best_bbox = draw.textbbox((0, 0), text, font=best_font)

    # Вычисляем смещение для выравнивания по верху и слева
    text_width = best_bbox[2] - best_bbox[0]
    text_height = best_bbox[3] - best_bbox[1]
    offset_x = -best_bbox[0]  # компенсация смещения из-за descender/ascender
    offset_y = -best_bbox[1]

    # Ограничиваем, чтобы текст не вылезал за нижнюю границу
    actual_y = y
    if text_height > max_height:
        actual_y = y  # уже на пределе, ничего не поделать
    else:
        # можно немного центрировать по вертикали, если нужно:
        # actual_y = y + (max_height - text_height) // 2
        pass

    draw.text((x + offset_x, actual_y + offset_y), text, fill=fill_color, font=best_font)
    return best_font
def generate_background(employee_data):
    img = Image.open(BACKGROUND_IMAGE_PATH).resize((1920, 1080), Image.LANCZOS)
    draw = ImageDraw.Draw(img, "RGBA")

    bg_brightness = get_background_brightness(BACKGROUND_IMAGE_PATH)
    is_light_bg = bg_brightness > 100
    level = employee_data.get("privacy_level", "low")
    display_data = {}
    if level in ["low", "medium", "high"]:
        display_data.update({
            "full_name": employee_data.get("full_name"),
            "position": employee_data.get("position")
        })
    if level in ["medium", "high"]:
        display_data.update({
            "company": employee_data.get("company"),
            "department": employee_data.get("department"),
            "office_location": employee_data.get("office_location")
        })
    if level == "high":
        contact = employee_data.get("contact", {})
        branding = employee_data.get("branding", {})
        display_data.update({
            "email": contact.get("email"),
            "telegram": contact.get("telegram"),
            "logo_url": branding.get("logo_url"),
            "slogan": branding.get("slogan")
        })

    # Цвета
    primary_color = (0, 0, 0) if is_light_bg else (255, 255, 255)
    secondary_color = (80, 80, 80) if is_light_bg else (200, 200, 200)
    has_branding_colors = False

    branding = employee_data.get("branding", {})
    corporate_colors = branding.get("corporate_colors", {})
    if corporate_colors and "primary" in corporate_colors and "secondary" in corporate_colors:
        try:
            primary_color = ImageColor.getrgb(corporate_colors["primary"])
            secondary_color = ImageColor.getrgb(corporate_colors["secondary"])
            has_branding_colors = True
        except:
            pass

    card_fill = (255, 255, 255) if is_light_bg else (0, 0, 0)
    at_bg_color = darken_color(secondary_color)

    # === Блок 1: ФИО и должность ===
    if display_data.get("full_name"):
        draw.rounded_rectangle([38, 36, 38 + 575, 36 + 100], fill=card_fill, radius=15)
        draw_text_in_box(draw, display_data["full_name"], 64, 56, 530, 60, primary_color)
    if display_data.get("position"):
        draw_text_in_box(draw, display_data["position"], 64, 56 + 40, 530, 40, secondary_color)

    # === Блок 2: Компания и департамент ===
    if display_data.get("company"):
        draw.rounded_rectangle([38, 144, 38 + 370, 144 + 425], fill=card_fill, radius=15)
        draw_text_in_box(draw, display_data["company"], 64, 163, 325, 40, primary_color)
    if display_data.get("department"):
        draw_text_in_box(draw, display_data["department"], 64, 163 + 35, 325, 35, secondary_color)

    # === Email ===
    if level == "high" and display_data.get("email"):
        draw.rounded_rectangle([1500, 41, 1500 + 384, 41 + 50], fill=card_fill, radius=15)
        draw.rounded_rectangle([1503, 44, 1503 + 44, 44 + 44], fill=secondary_color, radius=15)
        email_text = display_data["email"]
        draw_text_in_box(draw, email_text, 1551, 50, 370 - 50, 50, primary_color)
        draw.text((1508, 46), "@", fill=at_bg_color, font=load_font(32))

    # === Локация ===
    if display_data.get("office_location"):
        draw.rounded_rectangle([38, 577, 38 + 384, 577 + 50], fill=card_fill, radius=15)
        draw.rounded_rectangle([40, 580, 40 + 44, 580 + 44], fill=secondary_color, radius=15)
        loc_text = display_data["office_location"]
        draw_text_in_box(draw, loc_text, 90, 592, 375 - 50, 40, primary_color)
        try:
            icon = recolor_icon("/home/dusty/hackotons/human-segmentation-with-personal-backgrounds/Background_gen/location.png", at_bg_color)
            img.paste(icon, (47, 586), icon)
        except Exception as e:
            print(f"Иконка локации: {e}")

    # === Логотип ===
    if level == "high" and display_data.get("logo_url"):
        logo_img = load_image_from_url(display_data["logo_url"].strip())
        if logo_img:
            if logo_img.mode != "RGBA":
                logo_img = logo_img.convert("RGBA")
            block_w, block_h = 310, 310
            max_logo = min(block_w - 40, block_h - 40)
            logo_img.thumbnail((max_logo, max_logo), Image.LANCZOS)
            container = Image.new("RGBA", (block_w, block_h), (0, 0, 0, 0))
            d_cont = ImageDraw.Draw(container)
            d_cont.rounded_rectangle([0, 0, block_w - 1, block_h - 1], outline=primary_color, width=6, radius=30)
            x = (block_w - logo_img.width) // 2
            y = (block_h - logo_img.height) // 2
            container.paste(logo_img, (x, y), logo_img)
            img.paste(container, (64, 235), container)

    # === Telegram QR ===
    if level == "high" and display_data.get("telegram"):
        draw.rounded_rectangle([1508, 100, 1508 + 375, 100 + 425], fill=card_fill, radius=15)
        url = display_data["telegram"].replace("@", "https://t.me/").strip()
        qr_img = qr_round(url, primary_color, secondary_color, has_branding_colors)
        qr_img = qr_img.convert("RGBA").resize((335, 335), Image.LANCZOS)
        img.paste(qr_img, (1530, 120), qr_img)
        tg_text = display_data["telegram"]
        draw_text_in_box(draw, tg_text, 1535, 470, 325, 50, primary_color)

    # === Слоган ===
    if level == "high" and display_data.get("slogan"):
        slogan = f"«{display_data['slogan']}»"
        draw.rounded_rectangle([1508, 530, 1508 + 375, 530 + 50], fill=card_fill, radius=15)
        draw_text_in_box(draw, slogan, 1523, 543, 355, 50, primary_color)

    return img.convert("RGB")

# --- Пример ---
if __name__ == "__main__":
    sample_json_str = """
    {
      "employee": {
        "full_name": "Иванов Сергей Петрович",
        "position": "Ведущий инженер по компьютерному зрению",
        "company": "ООО «Рога и Копыта»",
        "department": "Департамент компьютерного зрения",
        "office_location": "Новосибирск, технопарк «Идея»",
        "contact": {
          "email": "sergey.ivanov@t1dp.ru",
          "telegram": "@sergey_vision"
        },
        "branding": {
          "logo_url": "https://upload.wikimedia.org/wikipedia/commons/thumb/2/2f/Google_2015_logo.svg/250px-Google_2015_logo.svg.png",
          "corporate_colors": {
            "primary": "#4285F4",
            "secondary": "#34A853"
          },
          "slogan": "Инновации в каждый кадр"
        },
        "privacy_level": "high"
      }
    }
    """

    try:
        data = json.loads(sample_json_str)
        img = generate_background(data["employee"])
        img.save("personalized_background_high.jpg", "JPEG", quality=100)
        print("✅ Сохранено!")
    except Exception as e:
        print(f"❌ Ошибка: {e}")